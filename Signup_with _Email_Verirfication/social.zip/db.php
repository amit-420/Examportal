<?php 


	$db_connect = mysqli_connect('localhost','root','','social');

		if (!$db_connect) {
			
			echo "There is somethint went wrong with your database.";
		}

 ?>